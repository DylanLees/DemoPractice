package com.woniuxy.hibernate.dao.impl;

import com.woniuxy.hibernate.entity.User;

public class UserDao extends BaseDaoImpl<User> {

}
