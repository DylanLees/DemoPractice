package com.woniuxy.hibernate.test;

import org.junit.Test;

import com.woniuxy.hibernate.dao.impl.UserDao;
import com.woniuxy.hibernate.entity.User;

public class UserDaoTest {

	@Test
	public void save(){
		UserDao userDao=new UserDao();
		User user=new User();
		user.setName("����");
		
		userDao.persist(user);
	}
	
	@Test
	public void find(){
		UserDao dao=new UserDao();
		User user = dao.find(1);
		System.out.println(user.getName());
	}
	
	@Test
	public void update(){
		UserDao dao=new UserDao();
		String hql="update User set name=? where id=?";
		dao.exectUpdateByJpql(hql, "����",1);
	}
	
}
